package data

import androidx.compose.ui.graphics.Color

data class SquareInfo(
    var posX: Double,
    var poY: Double,
    val color: Color,
    val des: String
)
