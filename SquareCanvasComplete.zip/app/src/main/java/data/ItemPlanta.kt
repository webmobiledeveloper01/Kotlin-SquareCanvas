package data

data class ItemPlanta(
    var codiPlanta: String,
    var descPlanta: String,
    var fitxerPlanta: String,
    )
